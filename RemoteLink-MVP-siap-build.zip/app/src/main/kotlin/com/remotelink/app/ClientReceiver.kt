package com.remotelink.app

import android.media.MediaCodec
import android.media.MediaFormat
import android.view.Surface
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class ClientReceiver(private val surface: Surface, private val status: (String) -> Unit) {
    private var socket: Socket? = null
    private var decoder: MediaCodec? = null
    private val running = AtomicBoolean(false)

    fun connect(host: String, port: Int) {
        Thread {
            try {
                val s = Socket(host, port)
                s.tcpNoDelay = true
                socket = s
                val input = DataInputStream(BufferedInputStream(s.getInputStream(), 64 * 1024))
                val magic = input.readInt()
                if (magic != 0x524C5031) throw IllegalStateException("Bukan koneksi RemoteLink")
                val width = input.readInt()
                val height = input.readInt()
                val csd0 = ByteArray(input.readInt()).also(input::readFully)
                val csd1 = ByteArray(input.readInt()).also(input::readFully)
                val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                    if (csd0.isNotEmpty()) setByteBuffer("csd-0", java.nio.ByteBuffer.wrap(csd0))
                    if (csd1.isNotEmpty()) setByteBuffer("csd-1", java.nio.ByteBuffer.wrap(csd1))
                }
                decoder = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                decoder!!.configure(format, surface, null, 0)
                decoder!!.start()
                running.set(true)
                status("Terhubung • menerima ${width}×${height}")
                val info = MediaCodec.BufferInfo()
                while (running.get()) {
                    val size = input.readInt()
                    val pts = input.readLong()
                    val flags = input.readInt()
                    if (size <= 0 || size > 10_000_000) throw IllegalStateException("Frame tidak valid")
                    val data = ByteArray(size)
                    input.readFully(data)
                    val index = decoder!!.dequeueInputBuffer(1_000_000)
                    if (index >= 0) {
                        val buf = decoder!!.getInputBuffer(index) ?: continue
                        buf.clear(); buf.put(data)
                        decoder!!.queueInputBuffer(index, 0, data.size, pts, flags)
                    }
                    var out = decoder!!.dequeueOutputBuffer(info, 0)
                    while (out >= 0) {
                        decoder!!.releaseOutputBuffer(out, true)
                        out = decoder!!.dequeueOutputBuffer(info, 0)
                    }
                }
            } catch (t: Throwable) {
                status("Koneksi berhenti: ${t.message ?: "kesalahan"}")
            } finally {
                close()
            }
        }.start()
    }

    fun close() {
        running.set(false)
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        try { decoder?.stop() } catch (_: Exception) {}
        try { decoder?.release() } catch (_: Exception) {}
        decoder = null
    }
}
