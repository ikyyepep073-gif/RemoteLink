package com.remotelink.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Surface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.widget.SurfaceView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import dagger.hilt.android.AndroidEntryPoint
import java.net.Inet4Address
import java.net.NetworkInterface

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var surface: SurfaceView
    private lateinit var ipInput: EditText
    private var clientReceiver: ClientReceiver? = null
    private var clientSurface: Surface? = null

    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(this, HostService::class.java).apply {
                putExtra(HostService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(HostService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, intent)
            status.text = "HOST aktif\nIP: ${localIp(this)}\nPort: 5000\nDi HP klien masukkan IP ini."
            Toast.makeText(this, "Berbagi layar dimulai", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.txtStatus)
        surface = findViewById(R.id.surfaceView)
        ipInput = findViewById(R.id.editIp)
        val host = findViewById<Button>(R.id.btnHost)
        val client = findViewById<Button>(R.id.btnClient)
        val connect = findViewById<Button>(R.id.btnConnect)

        surface.visibility = View.GONE
        ipInput.visibility = View.GONE
        connect.visibility = View.GONE

        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 40)
        }

        host.setOnClickListener {
            stopClient()
            val manager = getSystemService(MediaProjectionManager::class.java)
            projectionLauncher.launch(manager.createScreenCaptureIntent())
        }

        client.setOnClickListener {
            ipInput.visibility = View.VISIBLE
            connect.visibility = View.VISIBLE
            surface.visibility = View.VISIBLE
            status.text = "KLIEN\nMasukkan IP HP HOST lalu tekan HUBUNGKAN."
        }

        surface.holder.addCallback(object : android.view.SurfaceHolder.Callback {
            override fun surfaceCreated(holder: android.view.SurfaceHolder) { clientSurface = holder.surface }
            override fun surfaceChanged(holder: android.view.SurfaceHolder, format: Int, width: Int, height: Int) { clientSurface = holder.surface }
            override fun surfaceDestroyed(holder: android.view.SurfaceHolder) { clientSurface = null; stopClient() }
        })

        connect.setOnClickListener {
            val ip = ipInput.text.toString().trim()
            if (ip.isBlank()) {
                ipInput.error = "Masukkan IP HOST"
                return@setOnClickListener
            }
            val target = clientSurface
            if (target == null) {
                Toast.makeText(this, "Layar klien belum siap", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            stopClient()
            status.text = "Menghubungkan ke $ip:5000..."
            clientReceiver = ClientReceiver(target) { message -> runOnUiThread { status.text = message } }
            clientReceiver!!.connect(ip, 5000)
        }
    }

    private fun stopClient() {
        clientReceiver?.close()
        clientReceiver = null
    }

    override fun onDestroy() {
        stopClient()
        super.onDestroy()
    }

    companion object {
        fun localIp(context: Context): String {
            return try {
                NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
                    .firstOrNull { !it.isLoopbackAddress && it is Inet4Address }?.hostAddress ?: "Tidak diketahui"
            } catch (_: Exception) { "Tidak diketahui" }
        }
    }
}
