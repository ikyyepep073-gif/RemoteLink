package com.remotelink.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.Context
import android.view.WindowManager
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaCodecInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Surface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class HostService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "remotelink_host"
        private const val PORT = 5000
        private const val MAGIC = 0x524C5031 // RLP1
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var server: ServerSocket? = null
    private var client: Socket? = null
    private val running = AtomicBoolean(false)

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultData == null || resultCode == 0) {
            stopSelf()
            return START_NOT_STICKY
        }

        startForeground(1, notification("Menunggu perangkat klien di port $PORT"), foregroundType())
        if (!running.getAndSet(true)) {
            Thread { startHost(resultCode, resultData) }.start()
        }
        return START_NOT_STICKY
    }

    private fun foregroundType(): Int {
        return if (Build.VERSION.SDK_INT >= 29) {
            android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        } else 0
    }

    private fun startHost(resultCode: Int, data: Intent) {
        try {
            val manager = getSystemService(MediaProjectionManager::class.java)
            projection = manager.getMediaProjection(resultCode, data)
            val p = projection ?: throw IllegalStateException("MediaProjection tidak tersedia")
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.defaultDisplay.getRealMetrics(metrics)
            val scale = minOf(1f, 1280f / maxOf(metrics.widthPixels, metrics.heightPixels).toFloat())
            val width = ((metrics.widthPixels * scale).toInt() / 2) * 2
            val height = ((metrics.heightPixels * scale).toInt() / 2) * 2

            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
                setInteger(MediaFormat.KEY_FRAME_RATE, 30)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }
            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder!!.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = encoder!!.createInputSurface()
            encoder!!.start()

            virtualDisplay = p.createVirtualDisplay(
                "RemoteLink",
                width,
                height,
                metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface,
                null,
                null
            )

            server = ServerSocket(PORT)
            updateNotification("Host aktif • $width×$height • IP ${MainActivity.localIp(this)}:$PORT")
            client = server!!.accept()
            client!!.tcpNoDelay = true
            updateNotification("Klien terhubung • ${client!!.inetAddress.hostAddress}")
            streamToClient(client!!)
        } catch (t: Throwable) {
            updateNotification("Host berhenti: ${t.message ?: "kesalahan"}")
        } finally {
            stopSelf()
        }
    }

    private fun streamToClient(socket: Socket) {
        val output = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), 64 * 1024))
        val bufferInfo = MediaCodec.BufferInfo()
        var headerSent = false
        while (running.get() && !socket.isClosed) {
            val index = encoder?.dequeueOutputBuffer(bufferInfo, 100_000) ?: -1
            when {
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    val fmt = encoder!!.outputFormat
                    sendHeader(output, fmt)
                    headerSent = true
                }
                index >= 0 -> {
                    val buf = encoder!!.getOutputBuffer(index)
                    if (buf != null && bufferInfo.size > 0 && headerSent && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        buf.position(bufferInfo.offset)
                        buf.limit(bufferInfo.offset + bufferInfo.size)
                        val bytes = ByteArray(bufferInfo.size)
                        buf.get(bytes)
                        output.writeInt(bytes.size)
                        output.writeLong(bufferInfo.presentationTimeUs)
                        output.writeInt(bufferInfo.flags)
                        output.write(bytes)
                        output.flush()
                    }
                    encoder!!.releaseOutputBuffer(index, false)
                }
            }
        }
    }

    private fun sendHeader(out: DataOutputStream, format: MediaFormat) {
        val csd0 = format.getByteBuffer("csd-0")?.let { it.slice().let { b -> ByteArray(b.remaining()).also(b::get) } } ?: ByteArray(0)
        val csd1 = format.getByteBuffer("csd-1")?.let { it.slice().let { b -> ByteArray(b.remaining()).also(b::get) } } ?: ByteArray(0)
        out.writeInt(MAGIC)
        out.writeInt(format.getInteger(MediaFormat.KEY_WIDTH))
        out.writeInt(format.getInteger(MediaFormat.KEY_HEIGHT))
        out.writeInt(csd0.size)
        out.write(csd0)
        out.writeInt(csd1.size)
        out.write(csd1)
        out.flush()
    }

    override fun onDestroy() {
        running.set(false)
        try { client?.close() } catch (_: Exception) {}
        try { server?.close() } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { inputSurface?.release() } catch (_: Exception) {}
        try { encoder?.stop() } catch (_: Exception) {}
        try { encoder?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "RemoteLink Host", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun notification(text: String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("RemoteLink HOST").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_share).setOngoing(true).build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(1, notification(text))
    }
}
